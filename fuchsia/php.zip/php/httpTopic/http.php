
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Fuschia's Quizzer</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet"href="css/home.css" />
  <link rel="stylesheet" href="css/style.css" />
</head>

<body>

<h1>HTTP Quiz Type</h1>

<div class="card-deck">
  <div class="card">
    <div class="card-body">
      <a href="httpmul.php" class="btn btn-primary">Multiple Choice</a>
      <br></br>

        <div id="protocol">
        <form>
        <p>Number of Items:
           <select name="Number of Items">
               <option value=""></option>
               <option value="10">10</option>
               <option value="15">15</option>
               <option value="25">25</option>
           </select>
         </form>
       </p>
        </div>
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <a href="httpiden.jsp" class="btn btn-primary">Identification</a>
      <br></br>

      <div id="Cascade">
        <form>
        <p>Number of Items:
           <select name="Number of Items">
               <option value=""></option>
               <option value="10">10</option>
               <option value="15">15</option>
               <option value="25">25</option>
           </select>
         </form>
       </p>
        </div>
    </div>
  </div>
</div>
  
  <div id="previous">
   <nav aria-label="Page navigation example">
   <ul class="pagination justify-content-center">
    <li class="page-item ">
      <a class="page-link" href="../home.php" tabindex="-1">Previous</a>
    </li>
   </ul>
   </nav>
  </div>

</body>
</html>
