<?php

    $host = "localhost";
    $username = "root";
    $password = null;
    $dbName = "quizzer_fuscha";

    $connect = mysqli_connect($host,$username,$password,$dbName);
?>